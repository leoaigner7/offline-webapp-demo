.\venv\Scripts\Activate.ps1
Get-Content config.env | ForEach-Object {
  if ($_ -notmatch "^#") {
    $kv = $_.Split("=")
    [Environment]::SetEnvironmentVariable($kv[0], $kv[1])
  }
}
python app/main.py
